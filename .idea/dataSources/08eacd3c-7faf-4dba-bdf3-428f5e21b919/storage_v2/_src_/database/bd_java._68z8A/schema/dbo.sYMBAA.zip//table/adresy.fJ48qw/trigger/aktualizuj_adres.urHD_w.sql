create trigger aktualizuj_adres on adresy instead of update
as
declare @id int
declare @msc varchar(50)
declare @pow varchar(50)
declare @woj varchar(50)
declare @kod varchar(6)
declare @ul varchar(50)
declare @nrb int
declare @nrl int
select @id = id_adres from inserted
select @msc = miejscowosc from inserted
select @pow = powiat from inserted
select @woj = wojewodztwo from inserted
select @kod = kod_pocztowy from inserted
select @ul = ulica from inserted
select @nrb = nr_budynku from inserted
select @nrl = nr_lokalu from inserted
if @nrl = -1 or @nrl = null
begin
update adresy set miejscowosc = @msc, powiat = @pow, wojewodztwo = @woj, kod_pocztowy = @kod,
								ulica = @ul, nr_budynku = @nrb, nr_lokalu = null  where id_adres = @id
end
else 
begin
update adresy set miejscowosc = @msc, powiat = @pow, wojewodztwo = @woj, kod_pocztowy = @kod,
								ulica = @ul, nr_budynku = @nrb, nr_lokalu = @nrl  where id_adres = @id
end
go

