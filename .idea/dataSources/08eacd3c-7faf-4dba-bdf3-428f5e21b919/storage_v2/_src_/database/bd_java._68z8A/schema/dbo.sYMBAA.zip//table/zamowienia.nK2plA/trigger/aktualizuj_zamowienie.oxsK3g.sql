create trigger aktualizuj_zamowienie on zamowienia instead of update
as
declare @id int
declare @data datetime
declare @idkl int
declare @idpr int
declare @idprod int
declare @data_zl datetime
declare @czy_p varchar(3)
declare @czy_zap varchar(3)
declare @czy_zr varchar(3)
select @idprod = id_produkt from inserted
select @id = id_zamowienie from inserted
select @idkl = id_klient from inserted
select @idpr = id_pracownik from inserted
select @data_zl = data_zlozenia_zamowienia from inserted
select @czy_p = czy_przyjeto_zamowienie from inserted
select @czy_zap = czy_zaplacono from inserted
select @czy_zr = czy_zrealizowano_zamowienie from inserted
select @data = data_realizacji_zamowienia from inserted
if @data = '' or @data = null
begin
update zamowienia set id_klient=@idkl, id_pracownik=@idpr, id_produkt = @idprod,data_zlozenia_zamowienia = @data_zl,
czy_przyjeto_zamowienie = @czy_p, czy_zaplacono= @czy_zap, czy_zrealizowano_zamowienie = @czy_zr,
data_realizacji_zamowienia = null where id_zamowienie = @id
end
else 
begin
update zamowienia set id_klient=@idkl, id_pracownik=@idpr, id_produkt = @idprod, data_zlozenia_zamowienia = @data_zl,
czy_przyjeto_zamowienie = @czy_p, czy_zaplacono= @czy_zap, czy_zrealizowano_zamowienie = @czy_zr,
data_realizacji_zamowienia = @data where id_zamowienie = @id
end
go

