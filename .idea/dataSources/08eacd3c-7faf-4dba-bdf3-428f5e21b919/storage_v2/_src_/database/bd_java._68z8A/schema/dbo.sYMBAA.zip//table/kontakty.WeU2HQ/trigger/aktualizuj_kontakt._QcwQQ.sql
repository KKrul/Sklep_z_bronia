create trigger aktualizuj_kontakt on kontakty instead of update
as
declare @id int
declare @nr1 varchar(9)
declare @nr2 varchar(9)
declare @fax varchar(9)
declare @mail varchar(40)
declare @www varchar(50)
select @id = id_kontakt from inserted
select @nr1 = nr_tel_1 from inserted
select @nr2 = nr_tel_2 from inserted
select @fax = fax from inserted
select @mail = email from inserted
select @www = strona_www from inserted
if @nr2 = ''
begin
	if @fax = ''
	begin
		if @www = ''
		begin
			update kontakty set nr_tel_1 = @nr1, nr_tel_2=null, fax=null, email = @mail, strona_www=null where id_kontakt = @id
		end
		else
		begin
			update kontakty set nr_tel_1 = @nr1, nr_tel_2=null, fax=null, email = @mail, strona_www=@www where id_kontakt = @id
		end
	end
	else if @fax != '' and @www = ''
	begin
		update kontakty set nr_tel_1 = @nr1, nr_tel_2=null, fax=@fax, email = @mail, strona_www=null where id_kontakt = @id
	end
	else 
	begin
		update kontakty set nr_tel_1 = @nr1, nr_tel_2=null, fax=@fax, email = @mail, strona_www=@www where id_kontakt = @id
	end
end
else if @nr2 != '' and @fax = ''
begin
	if @www = ''
	begin
	update kontakty set nr_tel_1 = @nr1, nr_tel_2=@nr2, fax=null, email = @mail, strona_www=null where id_kontakt = @id
	end
	else
	begin
	update kontakty set nr_tel_1 = @nr1, nr_tel_2=@nr2, fax=null, email = @mail, strona_www=@www where id_kontakt = @id
	end
end
else
begin
	if @www != ''
	begin
	update kontakty set nr_tel_1 = @nr1, nr_tel_2=@nr2, fax=@fax, email = @mail, strona_www=@www where id_kontakt = @id
	end
	else
	begin
	update kontakty set nr_tel_1 = @nr1, nr_tel_2=@nr2, fax=@fax, email = @mail, strona_www=null where id_kontakt = @id
	end
end
go

