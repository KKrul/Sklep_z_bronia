create trigger dodaj_zamowienie on zamowienia instead of insert
as
declare @data datetime
declare @nulldata datetime
declare @idkl int
declare @idpr int
declare @idprod int
declare @data_zl datetime
declare @czy_p varchar(3)
declare @czy_zap varchar(3)
declare @czy_zr varchar(3)
select @idkl = id_klient from inserted
select @idpr = id_pracownik from inserted
select @idprod = id_produkt from inserted
select @data_zl = data_zlozenia_zamowienia from inserted
select @czy_p = czy_przyjeto_zamowienie from inserted
select @czy_zap = czy_zaplacono from inserted
select @czy_zr = czy_zrealizowano_zamowienie from inserted
select @data = data_realizacji_zamowienia from inserted
set @nulldata = null
if @data = '' or @data = null
begin
insert into zamowienia values(@idkl,@idpr,@idprod,@data_zl,@czy_p,@czy_zap,@czy_zr,@nulldata)
end
else 
begin
insert into zamowienia values(@idkl,@idpr,@idprod,@data_zl,@czy_p,@czy_zap,@czy_zr,@data)
end
go

