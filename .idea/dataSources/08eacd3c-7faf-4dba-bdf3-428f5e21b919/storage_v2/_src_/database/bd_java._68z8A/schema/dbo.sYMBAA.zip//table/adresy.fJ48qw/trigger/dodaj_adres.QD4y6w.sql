create trigger dodaj_adres on adresy instead of insert
as
declare @msc varchar(50)
declare @pow varchar(50)
declare @woj varchar(50)
declare @kod varchar(6)
declare @ul varchar(50)
declare @nrb int
declare @nrl int
select @msc = miejscowosc from inserted
select @pow = powiat from inserted
select @woj = wojewodztwo from inserted
select @kod = kod_pocztowy from inserted
select @ul = ulica from inserted
select @nrb = nr_budynku from inserted
select @nrl = nr_lokalu from inserted
if @nrl = -1 or @nrl = null
begin
insert into adresy values
(@msc,@pow,@woj,@kod,@ul,@nrb,null)
end
else 
begin
insert into adresy values
(@msc,@pow,@woj,@kod,@ul,@nrb,@nrl)
end
go

