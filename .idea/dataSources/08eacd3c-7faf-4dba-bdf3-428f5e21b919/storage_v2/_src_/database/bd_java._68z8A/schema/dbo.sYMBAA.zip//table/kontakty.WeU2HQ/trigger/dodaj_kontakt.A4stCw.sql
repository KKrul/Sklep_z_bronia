create trigger dodaj_kontakt on kontakty instead of insert
as
declare @nr1 varchar(9)
declare @nr2 varchar(9)
declare @fax varchar(9)
declare @mail varchar(40)
declare @www varchar(50)
select @nr1 = nr_tel_1 from inserted
select @nr2 = nr_tel_2 from inserted
select @fax = fax from inserted
select @mail = email from inserted
select @www = strona_www from inserted
if @nr2 = ''
begin
	if @fax = ''
	begin
		if @www = ''
		begin
			insert into kontakty values
			(@nr1,null,null,@mail,null) --1
		end
		else
		begin
			insert into kontakty values
			(@nr1,null,null,@mail,@www) --2
		end
	end
	else if @fax != '' and @www = ''
	begin
		insert into kontakty values
		(@nr1,null,@fax,@mail,null) --3
	end
	else 
	begin
		insert into kontakty values
		(@nr1,null,@fax,@mail,@www) --4
	end
end
else if @nr2 != '' and @fax = ''
begin
	if @www = ''
	begin
	insert into kontakty values
	(@nr1,@nr2,null,@mail,null) --5
	end
	else
	begin
	insert into kontakty values
	(@nr1,@nr2,null,@mail,@www) --6
	end
end
else
begin
	if @www != ''
	begin
	insert into kontakty values
	(@nr1,@nr2,@fax,@mail,@www) --7
	end
	else
	begin
	insert into kontakty values
	(@nr1,@nr2,@fax,@mail,null) --8
	end
end
go

